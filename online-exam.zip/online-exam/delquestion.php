<?php
session_start();
$qid=$_SESSION['admin'];
include 'conn.php';
$Qid=$_GET['Qid'];
$sql="delete  from questions where Qid='$Qid'";
 mysqli_query($con,$sql);
 header("location:QuestionList.php");
      
?>