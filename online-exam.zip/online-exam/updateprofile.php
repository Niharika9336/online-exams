<?php
session_start();
$em = $_SESSION['user'];
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
    crossorigin="anonymous"></script>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Profile</title>
    <style>
        /* CSS RESET  */
        body {
            margin: 0px;
            padding: 0px;
            background: url(Images/Student7.jpg);
            background-repeat: no-repeat;
            background-size: 1550px 800px;



        }

        .navbar {
            display: inline-block;
            border: 3px solid white;
            margin-left: 2%;
            margin-top: 25px;
            border-radius: 5px;
            /* position: fixed; */
        }

        .navbar li {
            display: inline-block;
        }

        .navbar li a {
            color: white;
            font-size: 23px;
            padding: 60px;
            text-decoration: none;
        }

        .navbar li a:hover {

            color: grey;
            font-size: 23px;
            padding: 60px;
            text-decoration: none;
        }

        .showprofile {
            width: 800px;
            border: 2px solid white;
            background-color: #1e272e;
            color: white;
            margin: 20px 320px;
            text-align: center;
            border-radius: 25px;
            padding: 20px 50px;
            box-shadow: 5px 5px 1rem lightgray inset;
        }

        th {
            color: white;
            font-size: 16pt;
            text-align: left;
            padding: 5px;
        }

        table {
            margin: 0px auto;
            width: 70%;
            border: 3px solid red;
        }

        .input {
            width: 270%;
            height: 40px;
            border: 2px solid grey;
            font-size: 16px;
            margin-left: 50px;
        }

        .mainb {
            color: #0652DD;
            padding: 8px;
            border-radius: 8px;
            font-size: 14pt;
            background-color: white;
            border: 2px solid #0652DD;
            transition: all 0.3s linear;
        }

        .mainb:hover {
            color: white;
            padding: 8px;
            border-radius: 8px;
            font-size: 14pt;
            background-color: #0652DD;
            border: 2px solid white;
            box-shadow: 2px 2px 2rem 2px grey;
        }

        h4 {
            display: inline-block;
            padding: 10px;
        }

        input {
            display: inline-block;
        }
    </style>
</head>

<body>
    <header>
        <div class="navbar">
            <ul>
                <li><a href="stu_profile.php"> Profile</a> </li>
                <li><a href="examstart.php">Exam</a></li>
                <li><a href="">Result</a></li>
                <li><a href="">Update Profile</a></li>
                <li><a href="stu_feedback.php">Feedback</a></li>
                <li><a href="stu_logout.php">Logout</a></li>
            </ul>
        </div>
        <hr>
    </header>

    <?php
    include 'conn.php';
    $sql = "select * from reg where uname='$em'";
    $qry = mysqli_query($con, $sql);
    while ($row = mysqli_fetch_assoc($qry)) {
        ?>

        <div class="showprofile">
            <h2>STUDENT PROFILE UPDATION</h2>
            <form action="" method="post" enctype="multipart/form-data">
            <!-- <h4>Username</h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input
                    type="file" name="file" value=br> -->
                   <?php  $img=$row['img'];  ?>
                <h4>Image</h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <?php echo "<img src='$img' height='100' width='100'>"?><br>         
                <h4>New Image</h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="img" ><br>
                <h4>Username</h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="text" name="uname" value="<?php echo $row['uname'] ?>"><br>
                <h4>Name</h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input
                    type="text" name="name" value="<?php echo $row['sname'] ?>"><br>
                <h4>Course</h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input
                    type="text" name="course" value="<?php echo $row['course'] ?>"><br>
                <h4>Gender</h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input
                    type="text" name="dob" value="<?php echo $row['dob'] ?>"><br>
                <h4>Gender</h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input
                    type="text" name="gender" value="<?php echo $row['gen'] ?>"><br>
                <h4>Address</h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input
                    type="text" name="address" value="<?php echo $row['address'] ?>"><br>
                <h4>City</h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input
                    type="text" name="city" value="<?php echo $row['city'] ?>"><br>
                <h4>state</h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input
                    type="text" name="state" value="<?php echo $row['state'] ?>"><br>
                <h4>Password</h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input
                    type="text" name="pass" value="<?php echo $row['pass'] ?>"><br>
                <h4>Pincode</h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input
                    type="number" name="pin" value="<?php echo $row['pin'] ?>"><br>
                <h4>Contact</h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input
                    type="number" name="cont" value="<?php echo $row['phone'] ?>"><br>
                <input type="submit" class="btn btn-outline-warning mt-2" name="update" value="update">
                <input type="reset" class="btn btn-outline-warning mt-2" name="reset">
      <?php
        if (isset($_POST['update'])) {
            $uname = $_POST['uname'];
            $sname = $_POST['name'];
            $cr = $_POST['course'];
            $dob = $_POST['dob'];
            $gen = $_POST['gender'];
            $add = $_POST['address'];
            $city = $_POST['city'];
            $st = $_POST['state'];
            $pass = $_POST['pass'];
            $pin = $_POST['pin'];
            $cont = $_POST['cont'];
            $image= $_FILES['img']['name'];
            $image_temp=$_FILES['img']['tmp_name'];
            $folder='UploadImage/' .$image;
            move_uploaded_file($image_temp ,$folder);
          
            $con = mysqli_connect("localhost", "root", "root", "online_exam");
            $sql1 = "update reg set sname='$sname',course='$cr',dob='$dob',gen='$gen',address='$add',city='$city', state='$st',pass='$pass', pin='$pin', phone='$cont', img='$folder' where uname='$em'";
            mysqli_query($con, $sql1);
//            header('location:student.php?profile updated successfully');
        }
      ?>
         <?php } ?> 
     </form>
    </div>
</body>
</html>

