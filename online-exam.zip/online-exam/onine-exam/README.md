# onine-exam
  Project Has Two Modules Students And Admin,Performs All Examination  Activities And Breaks The Constraints (Solves The Problems) Which Are  Faced During Offline Mode.
