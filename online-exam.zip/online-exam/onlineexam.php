Project Topic : Online Examination
There are 2 Type of User in this Project
(1) Admin
-------------------------------------------------------------------------------------------
(i) Admin can view Student List
(ii) Admin Can Add Question
(iii) Update Questions
(iv) Delete Question
(v) View Question List
(vi) View Exam Result
(vii) View Feedback
(viii) Change Password
(ix) Sign out

-------------------------------------------------------------------------------------------

(2) Student
(i) View Profile
(ii) Update Profile
(iii) Start Exam
(iv) View Result
(v) Feedback
(vi) Change Password
(vii) Sign out

-------------------------------------------------------------------------------------------

3.Student Registration

-------------------------------------------------------------------------------------------

4. Login for Admin and Student

-------------------------------------------------------------------------------------------